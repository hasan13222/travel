Downloaded by "Download All Images" extension

Page: https://sharetrip.net/hotel-search?currency=BDT&propertyCode=R956&checkin=2023-06-14&checkout=2023-06-16&nationality=bd&rooms=%5B%7B%22adults%22%3A2%2C%22children%22%3A%5B%5D%7D%5D&offset=0&limit=10&cityName=Cox%27s%20Bazar
Date: 6/12/2023, 9:19:43 AM

Name, Link
----------
full-logo.png, https://assets.sharetrip.net/media/assets/full-logo.png
spinner.svg, https://sharetrip.net/images/spinner.svg
R0tLrSOtupSDrAWPA--.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcK9g5KfVszD7qLeLMl+J7yKDF1fwmOwRls5cp34yF2fk0J3e/R0tLrSOtupSDrAWPA==
tripCoin.png, https://sharetrip.net/images/icons/tripCoin.png
tripCoinShare.png, https://sharetrip.net/images/icons/tripCoinShare.png
discount-mono.svg, https://sharetrip.net/images/icons/new/discount-mono.svg
BoVCzOh7xGrGyDDQzDMeVJWbLk-LUzF47Sub4ggP7jynY1p6Bo9gufLU3jQ-.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcIZEu//BoVCzOh7xGrGyDDQzDMeVJWbLk+LUzF47Sub4ggP7jynY1p6Bo9gufLU3jQ==
tvGridd5Ar9ZmNcHK0wtpUm2Lb8OaO0GndBFnCQngh47vAeALG-V7mqmqO2l.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcHK0wtpUm2Lb8OaO0GndBFnCQngh47vAeALG+V7mqmqO2lm2VrKC1nlAahAm3YiWPg==
8w26HhIlHDOjeFCsMnJ3xY1-aMXdW6u8TrqT1WTeSfegx1oGg--.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcMAnEP6HfMnlzf66/8w26HhIlHDOjeFCsMnJ3xY1+aMXdW6u8TrqT1WTeSfegx1oGg==
tvGridd5Ar9ZmNcMCej0dbfzqkf66bIAWCqSVLjA1wV41DDw9Spej9wz6Dv8.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcMCej0dbfzqkf66bIAWCqSVLjA1wV41DDw9Spej9wz6Dv8Dk9BSJVZJNCCIa136KCg==
QrEKJ6e5Abap6g3Z0RQU-3UdZKJ4dwmiCp330-fnN9hnKVyLMSpGr5kGhNKp.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcPH/QrEKJ6e5Abap6g3Z0RQU+3UdZKJ4dwmiCp330+fnN9hnKVyLMSpGr5kGhNKpWg==
rFLb0zQ--.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcFrDFQiGEijYBHfkK+4Z3DkTJfWRupg8Sz2i60XYz7WEuub0PRyez+gvu4/rFLb0zQ==
tvGridd5Ar9ZmNcCf4nV59mj-ooKCPK1eLHW5BtLm8h906jXHkgV9PQX2zoC.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcCf4nV59mj+ooKCPK1eLHW5BtLm8h906jXHkgV9PQX2zoCnoLFbOmxOsyRwgWRPRJA==
g--.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcL5Ezs7SVvADs/UBmcN2Inu2V4AQCBYQhI0pbsHjTBZ2uG90d6NSuZ2K/CDhKSdp/g==
0QL9Q6EMgjGOr7GTIXk-IDqaa4q6qSw--.jpeg, https://api.sharetrip.net/api/v1/hotel/image?key=HyANbffVjkBh1mA2CJLuNFZlI6UkKrgAbXWPt8bqt5XudxSGJg/auh/IeYO9o63FWll2h/tvGridd5Ar9ZmNcPTM8OcRpOtHeEYsWFDkzIlIDetC5aH8fy/0QL9Q6EMgjGOr7GTIXk+IDqaa4q6qSw==
facebook.svg, https://sharetrip.net/images/icons/social/facebook.svg
messenger.svg, https://sharetrip.net/images/icons/social/messenger.svg
twitter.svg, https://sharetrip.net/images/icons/social/twitter.svg
instagram.svg, https://sharetrip.net/images/icons/social/instagram.svg
youtube.svg, https://sharetrip.net/images/icons/social/youtube.svg
linkedin.svg, https://sharetrip.net/images/icons/social/linkedin.svg
basis.png, https://assets.sharetrip.net/media/assets/basis.png
e-cab.png, https://assets.sharetrip.net/e-cab.png
pata.svg, https://sharetrip.net/images/pata.svg
comodoSecure.png, https://assets.sharetrip.net/media/assets/comodoSecure.png
iata-logo.png, https://assets.sharetrip.net/media/assets/iata-logo.png
bimanbd.png, https://assets.sharetrip.net/bimanbd.png
google-partner.png, https://assets.sharetrip.net/google-partner.png
duns-certified-by.png, https://assets.sharetrip.net/duns-certified-by.png
footer-payment-method.png, https://assets.sharetrip.net/footer-payment-method.png
image.gif, https://image.crisp.chat/avatar/operator/6b2c36f4-3bbe-4779-ae10-4d508e5c8ca4/60/?1685892568205
image.jpeg, https://image.crisp.chat/avatar/website/14009585-79af-47ed-ab9a-4b2d8133a3bd/60/?1685892568205
banner.webp, https://sharetrip.net/assets/images/banner.webp
image.gif, https://googleads.g.doubleclick.net/pagead/viewthroughconversion/818907222/?random=1686531603259&cv=11&fst=1686531603259&bg=ffffff&guid=ON&async=1&gtm=45He3671&u_w=1366&u_h=768&url=https%3A%2F%2Fsharetrip.net%2Fhotel-search%3Fcurrency%3DBDT%26propertyCode%3DR956%26checkin%3D2023-06-14%26checkout%3D2023-06-16%26nationality%3Dbd%26rooms%3D%255B%257B%2522adults%2522%253A2%252C%2522children%2522%253A%255B%255D%257D%255D%26offset%3D0%26limit%3D10%26cityName%3DCox%2527s%2520Bazar&ref=https%3A%2F%2Fsharetrip.net%2F&label=gtm.jshttps%3A%2F%2Fsharetrip.net%2Fhotel-search%3Fcurrency%3DBDT%26propertyCode%3DR956%26checkin%3D2023-06-14%26checkout%3D2023-06-16%26nationality%3Dbd%26rooms%3D%255B%257B%2522adults%2522%253A2%252C%2522children%2522%253A%255B%255D%257D%255D%26offset%3D0%26limit%3D10%26cityName%3DCox%2527s%2520Bazar&hn=www.googleadservices.com&frm=0&tiba=Book%20Cheap%20Hotels%20online%20-%20ShareTrip&auid=1336913571.1685712945&uaa=x86&uab=64&uafvl=Not.A%252FBrand%3B8.0.0.0%7CChromium%3B114.0.5735.110%7CGoogle%2520Chrome%3B114.0.5735.110&uamb=0&uap=Windows&uapv=8.0.0&uaw=0&data=event%3DRemarketing%20Event%20Data
